import { getEnv } from "akanjs/base";

import type { ModulesOptions } from "../lib/option";

export const env: ModulesOptions = {
  ...getEnv(),
  
};

